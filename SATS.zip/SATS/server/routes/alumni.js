// server/routes/alumni.js
const express = require('express');
const router = express.Router();
const Alumni = require('../models/Alumni');

// GET all alumni
router.get('/', async (req, res) => {
  const alumni = await Alumni.find();
  res.json(alumni);
});

// GET one alumni
router.get('/:id', async (req, res) => {
  const alumni = await Alumni.findById(req.params.id);
  res.json(alumni);
});

// POST new alumni
router.post('/', async (req, res) => {
  const newAlumni = new Alumni(req.body);
  await newAlumni.save();
  res.json(newAlumni);
});

// PUT update alumni
router.put('/:id', async (req, res) => {
  const updated = await Alumni.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// DELETE alumni
router.delete('/:id', async (req, res) => {
  await Alumni.findByIdAndDelete(req.params.id);
  res.json({ message: 'Alumni deleted' });
});

module.exports = router;

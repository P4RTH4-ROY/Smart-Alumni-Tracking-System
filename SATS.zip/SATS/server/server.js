//
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");

// ==== Replace with your actual connection string ====
const mongoURI = "mongodb+srv://is2270415:Mal0aX6loeo55roC@testing-mern.eomy7kk.mongodb.net/?retryWrites=true&w=majority&appName=TESTING-MERN";

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB
mongoose
  .connect(mongoURI)
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log("MongoDB connection error:", err));

// Define Alumni Schema
const alumniSchema = new mongoose.Schema({
  name: { type: String, required: true },
  department: String,
  batch: String,
  mobile: String,
  currentPosition: String,
  linkedinProfile: String,
});

const Alumni = mongoose.model("Alumni", alumniSchema);

// Routes

// Get all alumni
app.get("/api/alumni", async (req, res) => {
  try {
    const alumniList = await Alumni.find();
    res.json(alumniList);
  } catch (err) {
    res.status(500).json({ message: "Server error fetching alumni" });
  }
});

// Add new alumni
app.post("/api/alumni", async (req, res) => {
  const { name, department, batch, mobile, currentPosition, linkedinProfile } = req.body;
  if (!name) return res.status(400).json({ message: "Name is required" });

  try {
    const newAlumni = new Alumni({
      name,
      department,
      batch,
      mobile,
      currentPosition,
      linkedinProfile,
    });
    const savedAlumni = await newAlumni.save();
    res.status(201).json(savedAlumni);
  } catch (err) {
    res.status(500).json({ message: "Error saving alumni" });
  }
});

// Update alumni by ID
app.put("/api/alumni/:id", async (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  try {
    const updatedAlumni = await Alumni.findByIdAndUpdate(id, updates, { new: true });
    if (!updatedAlumni) return res.status(404).json({ message: "Alumni not found" });
    res.json(updatedAlumni);
  } catch (err) {
    res.status(500).json({ message: "Error updating alumni" });
  }
});

// Delete alumni by ID
app.delete("/api/alumni/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const deleted = await Alumni.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ message: "Alumni not found" });
    res.json({ message: "Alumni deleted" });
  } catch (err) {
    res.status(500).json({ message: "Error deleting alumni" });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// client/src/components/AlumniList.jsx
import axios from "axios";

const AlumniList = ({ alumni, fetchAlumni, setSelected }) => {
  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/api/alumni/${id}`);
    fetchAlumni();
  };

  return (
    <div>
      <h2>Alumni List</h2>
      <ul>
        {alumni.map((a) => (
          <li key={a._id}>
            <strong>{a.name}</strong> | {a.batch} | {a.department} | {a.currentPosition}
            <button onClick={() => setSelected(a)}>Edit</button>
            <button onClick={() => handleDelete(a._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AlumniList;

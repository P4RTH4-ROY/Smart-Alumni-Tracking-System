// client/src/components/AlumniForm.jsx
import { useState, useEffect } from "react";
import axios from "axios";

const AlumniForm = ({ selected, fetchAlumni, setSelected }) => {
  const [formData, setFormData] = useState({
    name: "",
    batch: "",
    department: "",
    email: "",
    phone: "",
    currentPosition: "",
  });

  useEffect(() => {
    if (selected) setFormData(selected);
  }, [selected]);

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (selected) {
      await axios.put(`http://localhost:5000/api/alumni/${selected._id}`, formData);
    } else {
      await axios.post("http://localhost:5000/api/alumni", formData);
    }
    setFormData({
      name: "",
      batch: "",
      department: "",
      email: "",
      phone: "",
      currentPosition: "",
    });
    setSelected(null);
    fetchAlumni();
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "2rem" }}>
      <input name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
      <input name="batch" placeholder="Batch" value={formData.batch} onChange={handleChange} required />
      <input name="department" placeholder="Department" value={formData.department} onChange={handleChange} required />
      <input name="email" placeholder="Email" value={formData.email} onChange={handleChange} />
      <input name="phone" placeholder="Phone" value={formData.phone} onChange={handleChange} />
      <input name="currentPosition" placeholder="Current Position" value={formData.currentPosition} onChange={handleChange} />
      <button type="submit">{selected ? "Update" : "Add"} Alumni</button>
    </form>
  );
};

export default AlumniForm;

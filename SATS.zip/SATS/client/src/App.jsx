import React, { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";
import logo from "./logo.png"; // Ensure logo.png exists in src folder

function App() {
  const [formData, setFormData] = useState({
    name: "",
    department: "",
    batch: "",
    mobile: "",
    currentPosition: "",
    linkedinProfile: "",
  });

  const [alumniList, setAlumniList] = useState([]);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [editingId, setEditingId] = useState(null);

  const fetchAlumni = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/alumni");
      setAlumniList(res.data);
    } catch (error) {
      setMessage({ type: "error", text: "Failed to load alumni list." });
    }
  };

  useEffect(() => {
    fetchAlumni();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setFormData({
      name: "",
      department: "",
      batch: "",
      mobile: "",
      currentPosition: "",
      linkedinProfile: "",
    });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name) {
      setMessage({ type: "error", text: "Name is required." });
      return;
    }

    try {
      if (editingId) {
        await axios.put(`http://localhost:5000/api/alumni/${editingId}`, formData);
        setMessage({ type: "success", text: "Alumni updated successfully!" });
      } else {
        await axios.post("http://localhost:5000/api/alumni", formData);
        setMessage({ type: "success", text: "Alumni registered successfully!" });
      }
      resetForm();
      fetchAlumni();
    } catch (error) {
      setMessage({ type: "error", text: "Failed to submit form." });
    }
  };

  const handleEdit = (alumni) => {
    setFormData({
      name: alumni.name || "",
      department: alumni.department || "",
      batch: alumni.batch || "",
      mobile: alumni.mobile || "",
      currentPosition: alumni.currentPosition || "",
      linkedinProfile: alumni.linkedinProfile || "",
    });
    setEditingId(alumni._id);
    setMessage({ type: "", text: "" });
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this alumni?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/alumni/${id}`);
      setMessage({ type: "success", text: "Alumni deleted successfully!" });
      fetchAlumni();
    } catch (error) {
      setMessage({ type: "error", text: "Failed to delete alumni." });
    }
  };

  return (
    <div className="container">
      <header className="header">
        <img src={logo} alt="USTC Logo" className="logo" />
        <h1 className="title">USTC Alumni Tracking System</h1>
      </header>

      <section className="alumni-form">
        <h2>{editingId ? "Edit Alumni" : "Register Alumni"}</h2>
        <form onSubmit={handleSubmit}>
          <label>Name *</label>
          <input name="name" value={formData.name} onChange={handleChange} required />

          <label>Department</label>
          <input name="department" value={formData.department} onChange={handleChange} />

          <label>Batch</label>
          <input name="batch" value={formData.batch} onChange={handleChange} />

          <label>Mobile Number</label>
          <input name="mobile" value={formData.mobile} onChange={handleChange} />

          <label>Current Position</label>
          <input name="currentPosition" value={formData.currentPosition} onChange={handleChange} />

          <label>LinkedIn Profile</label>
          <input name="linkedinProfile" value={formData.linkedinProfile} onChange={handleChange} />

          <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap", marginTop: "20px" }}>
            <button type="submit">{editingId ? "Update" : "Submit"}</button>
            {editingId && (
              <button type="button" className="cancel-btn" onClick={resetForm}>
                Cancel
              </button>
            )}
            {message.text && (
              <span className={message.type === "success" ? "success-inline" : "error-inline"}>
                {message.text}
              </span>
            )}
          </div>
        </form>
      </section>

      <section className="alumni-list-section">
        <h2>Registered Alumni</h2>
        {alumniList.length === 0 ? (
          <p>No alumni registered yet.</p>
        ) : (
          <table className="alumni-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Department</th>
                <th>Batch</th>
                <th>Mobile</th>
                <th>Current Position</th>
                <th>LinkedIn</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {alumniList.map((alumni) => (
                <tr key={alumni._id}>
                  <td>{alumni.name}</td>
                  <td>{alumni.department}</td>
                  <td>{alumni.batch}</td>
                  <td>{alumni.mobile}</td>
                  <td>{alumni.currentPosition}</td>
                  <td>
                    {alumni.linkedinProfile ? (
                      <a href={alumni.linkedinProfile} target="_blank" rel="noopener noreferrer">
                        Profile
                      </a>
                    ) : (
                      "-"
                    )}
                  </td>
                  <td>
                    <button className="edit-btn" onClick={() => handleEdit(alumni)}>Edit</button>
                    <button className="delete-btn" onClick={() => handleDelete(alumni._id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}

export default App;
